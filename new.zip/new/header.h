#include<iostream>
#include<limits.h>
#include <stdio.h>
#include<stdlib.h>
#include <iostream>
#include <boost/thread.hpp>
#include <boost/functional.hpp>
#include<ctype.h>

#define V 5

void find_path(int g[V][V], int src);
int printSolution(int dist[], int n);
int minDistance(int dist[], bool sptSet[]);
void update_file();
